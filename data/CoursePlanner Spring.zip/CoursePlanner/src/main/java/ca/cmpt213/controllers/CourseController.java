package ca.cmpt213.controllers;

import ca.cmpt213.model.CSVFileReader;
import ca.cmpt213.model.CourseList;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.*;

import java.io.File;

@RestController
public class CourseController {
    private final String input = "data/course_data_2018.csv";
    File inputFile = new File(input);
    CourseList c = new CourseList(new CSVFileReader(inputFile));

    //GET /api/dump-model
    @GetMapping("/api/dump-model")
    public void dumpModel() {
        c.printCourseList();
    }
}
